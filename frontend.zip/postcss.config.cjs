// frontend/postcss.config.js
module.exports = {
  plugins: {
    '@tailwindcss/postcss': {},   // ← 변경
    autoprefixer: {},
  },
};
