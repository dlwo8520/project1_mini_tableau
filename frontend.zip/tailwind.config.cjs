/** @type {import('tailwindcss').Config} */
module.exports = {
  theme: {
    extend: {
      colors: {
        /* 내가 추가한 색 */
        primary: {
          50:  '#f0f9ff',
          100: '#e0f2fe',
          // …
        },
      },
      fontFamily: {
        body: ['Inter', 'sans-serif'],
        heading: ['Inter', 'sans-serif'],
      },
    },
  },
};